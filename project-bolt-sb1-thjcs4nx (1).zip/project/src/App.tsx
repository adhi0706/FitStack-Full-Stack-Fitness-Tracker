import React, { useState } from 'react';
import Navigation from './components/Navigation';
import Dashboard from './components/Dashboard';
import WorkoutTracker from './components/WorkoutTracker';
import ExerciseLibrary from './components/ExerciseLibrary';
import ProgressTracker from './components/ProgressTracker';
import Profile from './components/Profile';
import { useWorkouts } from './hooks/useLocalStorage';

function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const { workouts, addWorkout } = useWorkouts();

  const handleSaveWorkout = (workoutData: any) => {
    addWorkout(workoutData);
    setActiveTab('dashboard');
  };

  const renderActiveComponent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard workouts={workouts} />;
      case 'workout':
        return <WorkoutTracker onSaveWorkout={handleSaveWorkout} />;
      case 'exercises':
        return <ExerciseLibrary />;
      case 'progress':
        return <ProgressTracker workouts={workouts} />;
      case 'profile':
        return <Profile workouts={workouts} />;
      default:
        return <Dashboard workouts={workouts} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="flex flex-col md:flex-row">
        {/* Navigation */}
        <Navigation activeTab={activeTab} onTabChange={setActiveTab} />
        
        {/* Main Content */}
        <main className="flex-1 md:ml-0 pb-20 md:pb-0">
          <div className="p-4 md:p-6 lg:p-8 max-w-7xl mx-auto">
            {renderActiveComponent()}
          </div>
        </main>
      </div>
    </div>
  );
}

export default App;