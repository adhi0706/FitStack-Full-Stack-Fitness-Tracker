import React, { useState } from 'react';
import { Plus, Play, Square, Timer, Weight, RotateCcw, CheckCircle } from 'lucide-react';
import { exerciseDatabase } from '../data/exercises';

interface WorkoutTrackerProps {
  onSaveWorkout: (workout: any) => void;
}

const WorkoutTracker: React.FC<WorkoutTrackerProps> = ({ onSaveWorkout }) => {
  const [workoutName, setWorkoutName] = useState('');
  const [selectedExercises, setSelectedExercises] = useState<any[]>([]);
  const [isWorkoutActive, setIsWorkoutActive] = useState(false);
  const [startTime, setStartTime] = useState<Date | null>(null);
  const [currentTime, setCurrentTime] = useState<Date>(new Date());

  React.useEffect(() => {
    if (isWorkoutActive) {
      const timer = setInterval(() => setCurrentTime(new Date()), 1000);
      return () => clearInterval(timer);
    }
  }, [isWorkoutActive]);

  const getWorkoutDuration = () => {
    if (!startTime) return 0;
    return Math.floor((currentTime.getTime() - startTime.getTime()) / 1000);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const startWorkout = () => {
    if (!workoutName.trim()) {
      alert('Please enter a workout name');
      return;
    }
    setIsWorkoutActive(true);
    setStartTime(new Date());
  };

  const endWorkout = () => {
    const duration = Math.floor(getWorkoutDuration() / 60);
    const totalWeight = selectedExercises.reduce((sum, ex) => 
      sum + ex.sets.reduce((setSum: number, set: any) => setSum + (set.weight * set.reps), 0), 0
    );
    const totalSets = selectedExercises.reduce((sum, ex) => sum + ex.sets.length, 0);

    const workout = {
      name: workoutName,
      duration,
      exercises: selectedExercises,
      totalWeight,
      totalSets,
      completed: true
    };

    onSaveWorkout(workout);
    
    // Reset state
    setWorkoutName('');
    setSelectedExercises([]);
    setIsWorkoutActive(false);
    setStartTime(null);
  };

  const addExercise = (exercise: any) => {
    const workoutExercise = {
      ...exercise,
      sets: [{ reps: 10, weight: 0, completed: false }]
    };
    setSelectedExercises([...selectedExercises, workoutExercise]);
  };

  const addSet = (exerciseIndex: number) => {
    const updated = [...selectedExercises];
    const lastSet = updated[exerciseIndex].sets[updated[exerciseIndex].sets.length - 1];
    updated[exerciseIndex].sets.push({ 
      reps: lastSet.reps, 
      weight: lastSet.weight, 
      completed: false 
    });
    setSelectedExercises(updated);
  };

  const updateSet = (exerciseIndex: number, setIndex: number, field: string, value: any) => {
    const updated = [...selectedExercises];
    updated[exerciseIndex].sets[setIndex][field] = value;
    setSelectedExercises(updated);
  };

  const removeExercise = (exerciseIndex: number) => {
    setSelectedExercises(selectedExercises.filter((_, i) => i !== exerciseIndex));
  };

  if (!isWorkoutActive) {
    return (
      <div className="space-y-6">
        {/* Workout Setup */}
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <h2 className="text-xl font-bold text-gray-900 mb-4">Start New Workout</h2>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Workout Name
              </label>
              <input
                type="text"
                value={workoutName}
                onChange={(e) => setWorkoutName(e.target.value)}
                placeholder="e.g., Upper Body, Leg Day, Full Body"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
              />
            </div>
            
            {selectedExercises.length > 0 && (
              <div className="space-y-3">
                <h3 className="font-medium text-gray-900">Selected Exercises:</h3>
                {selectedExercises.map((exercise, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <span className="font-medium">{exercise.name}</span>
                    <button
                      onClick={() => removeExercise(index)}
                      className="text-red-500 hover:text-red-700 transition-colors"
                    >
                      Remove
                    </button>
                  </div>
                ))}
              </div>
            )}

            <button
              onClick={startWorkout}
              disabled={!workoutName.trim() || selectedExercises.length === 0}
              className="w-full bg-gradient-to-r from-blue-600 to-blue-700 text-white py-3 px-6 rounded-lg font-medium hover:from-blue-700 hover:to-blue-800 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 flex items-center justify-center space-x-2"
            >
              <Play className="w-5 h-5" />
              <span>Start Workout</span>
            </button>
          </div>
        </div>

        {/* Exercise Library */}
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Add Exercises</h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {exerciseDatabase.map((exercise) => (
              <div key={exercise.id} className="border border-gray-200 rounded-lg p-4 hover:border-blue-300 hover:shadow-sm transition-all">
                <div className="flex items-start justify-between mb-2">
                  <h4 className="font-medium text-gray-900">{exercise.name}</h4>
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    exercise.difficulty === 'beginner' ? 'bg-green-100 text-green-700' :
                    exercise.difficulty === 'intermediate' ? 'bg-yellow-100 text-yellow-700' :
                    'bg-red-100 text-red-700'
                  }`}>
                    {exercise.difficulty}
                  </span>
                </div>
                <p className="text-sm text-gray-600 mb-2">{exercise.category}</p>
                <p className="text-xs text-gray-500 mb-3">
                  {exercise.muscleGroups.join(', ')}
                </p>
                <button
                  onClick={() => addExercise(exercise)}
                  className="w-full bg-blue-50 text-blue-600 py-2 px-3 rounded-lg text-sm font-medium hover:bg-blue-100 transition-colors flex items-center justify-center space-x-1"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add to Workout</span>
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Active Workout Header */}
      <div className="bg-gradient-to-r from-emerald-600 to-blue-600 rounded-xl p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl md:text-2xl font-bold">{workoutName}</h2>
            <p className="text-emerald-100">Workout in Progress</p>
          </div>
          <div className="text-right">
            <div className="flex items-center space-x-2 text-2xl font-mono font-bold">
              <Timer className="w-6 h-6" />
              <span>{formatTime(getWorkoutDuration())}</span>
            </div>
            <p className="text-emerald-100 text-sm">Duration</p>
          </div>
        </div>
      </div>

      {/* Exercise Sets */}
      <div className="space-y-4">
        {selectedExercises.map((exercise, exerciseIndex) => (
          <div key={exerciseIndex} className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-lg font-semibold text-gray-900">{exercise.name}</h3>
                <p className="text-sm text-gray-500">{exercise.muscleGroups.join(', ')}</p>
              </div>
              <button
                onClick={() => addSet(exerciseIndex)}
                className="bg-blue-50 text-blue-600 p-2 rounded-lg hover:bg-blue-100 transition-colors"
              >
                <Plus className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3">
              <div className="grid grid-cols-4 gap-3 text-sm font-medium text-gray-500 px-2">
                <span>Set</span>
                <span>Reps</span>
                <span>Weight (lbs)</span>
                <span>Done</span>
              </div>
              
              {exercise.sets.map((set: any, setIndex: number) => (
                <div key={setIndex} className="grid grid-cols-4 gap-3 items-center p-2 bg-gray-50 rounded-lg">
                  <span className="font-medium text-gray-700">{setIndex + 1}</span>
                  
                  <input
                    type="number"
                    value={set.reps}
                    onChange={(e) => updateSet(exerciseIndex, setIndex, 'reps', parseInt(e.target.value) || 0)}
                    className="px-3 py-2 border border-gray-300 rounded-lg text-center focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    min="1"
                  />
                  
                  <input
                    type="number"
                    value={set.weight}
                    onChange={(e) => updateSet(exerciseIndex, setIndex, 'weight', parseFloat(e.target.value) || 0)}
                    className="px-3 py-2 border border-gray-300 rounded-lg text-center focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    min="0"
                    step="2.5"
                  />
                  
                  <button
                    onClick={() => updateSet(exerciseIndex, setIndex, 'completed', !set.completed)}
                    className={`p-2 rounded-lg transition-all duration-200 ${
                      set.completed 
                        ? 'bg-green-100 text-green-600 hover:bg-green-200' 
                        : 'bg-gray-200 text-gray-400 hover:bg-gray-300'
                    }`}
                  >
                    <CheckCircle className="w-5 h-5" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Finish Workout */}
      <div className="flex space-x-4">
        <button
          onClick={() => setIsWorkoutActive(false)}
          className="flex-1 bg-gray-100 text-gray-700 py-3 px-6 rounded-lg font-medium hover:bg-gray-200 transition-colors flex items-center justify-center space-x-2"
        >
          <RotateCcw className="w-5 h-5" />
          <span>Cancel</span>
        </button>
        <button
          onClick={endWorkout}
          className="flex-1 bg-gradient-to-r from-emerald-600 to-emerald-700 text-white py-3 px-6 rounded-lg font-medium hover:from-emerald-700 hover:to-emerald-800 transition-all duration-200 flex items-center justify-center space-x-2"
        >
          <Square className="w-5 h-5" />
          <span>Finish Workout</span>
        </button>
      </div>
    </div>
  );
};

export default WorkoutTracker;