import React, { useState } from 'react';
import { User, Settings, Target, Calendar, Trophy, Edit3, Save, X } from 'lucide-react';
import { useLocalStorage } from '../hooks/useLocalStorage';

interface ProfileProps {
  workouts: any[];
}

const Profile: React.FC<ProfileProps> = ({ workouts }) => {
  const [profile, setProfile] = useLocalStorage('fitstack-profile', {
    name: 'Fitness Enthusiast',
    email: 'user@fitstack.com',
    age: 25,
    weight: 150,
    height: 68,
    fitnessGoal: 'maintain',
    weeklyGoal: 3,
    joinDate: new Date().toISOString(),
  });

  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState(profile);

  const handleSave = () => {
    setProfile(editForm);
    setIsEditing(false);
  };

  const handleCancel = () => {
    setEditForm(profile);
    setIsEditing(false);
  };

  const totalWorkouts = workouts.length;
  const totalWeight = workouts.reduce((sum, w) => sum + (w.totalWeight || 0), 0);
  const totalDuration = workouts.reduce((sum, w) => sum + (w.duration || 0), 0);
  const joinDate = new Date(profile.joinDate);
  const daysActive = Math.floor((new Date().getTime() - joinDate.getTime()) / (1000 * 60 * 60 * 24));

  const thisWeekWorkouts = workouts.filter(w => {
    const workoutDate = new Date(w.date);
    const now = new Date();
    const weekStart = new Date(now.setDate(now.getDate() - now.getDay()));
    return workoutDate >= weekStart;
  }).length;

  const weeklyProgress = (thisWeekWorkouts / profile.weeklyGoal) * 100;

  const achievements = [
    { 
      title: 'First Steps', 
      description: 'Completed your first workout', 
      earned: totalWorkouts > 0,
      icon: '🎯'
    },
    { 
      title: 'Consistency', 
      description: 'Worked out 5 times', 
      earned: totalWorkouts >= 5,
      icon: '🔥'
    },
    { 
      title: 'Heavy Lifter', 
      description: 'Lifted over 5,000 lbs total', 
      earned: totalWeight >= 5000,
      icon: '💪'
    },
    { 
      title: 'Marathon', 
      description: 'Trained for over 10 hours total', 
      earned: totalDuration >= 600,
      icon: '⏰'
    },
    { 
      title: 'Dedicated', 
      description: 'Completed 20 workouts', 
      earned: totalWorkouts >= 20,
      icon: '🏆'
    },
    { 
      title: 'Beast Mode', 
      description: 'Lifted over 10,000 lbs total', 
      earned: totalWeight >= 10000,
      icon: '🦁'
    },
  ];

  const earnedAchievements = achievements.filter(a => a.earned);

  return (
    <div className="space-y-6">
      {/* Profile Header */}
      <div className="bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 rounded-xl p-6 text-white">
        <div className="flex items-start justify-between">
          <div className="flex items-center space-x-4">
            <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm">
              <User className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">{profile.name}</h1>
              <p className="text-indigo-100">{profile.email}</p>
              <p className="text-indigo-200 text-sm">
                Member since {joinDate.toLocaleDateString()}
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsEditing(true)}
            className="bg-white/20 backdrop-blur-sm p-2 rounded-lg hover:bg-white/30 transition-colors"
          >
            <Edit3 className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Edit Modal */}
      {isEditing && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl p-6 w-full max-w-md">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-gray-900">Edit Profile</h2>
              <button onClick={handleCancel} className="text-gray-400 hover:text-gray-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Name</label>
                <input
                  type="text"
                  value={editForm.name}
                  onChange={(e) => setEditForm({...editForm, name: e.target.value})}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
                <input
                  type="email"
                  value={editForm.email}
                  onChange={(e) => setEditForm({...editForm, email: e.target.value})}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Age</label>
                  <input
                    type="number"
                    value={editForm.age}
                    onChange={(e) => setEditForm({...editForm, age: parseInt(e.target.value) || 0})}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Weight (lbs)</label>
                  <input
                    type="number"
                    value={editForm.weight}
                    onChange={(e) => setEditForm({...editForm, weight: parseInt(e.target.value) || 0})}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Height (inches)</label>
                <input
                  type="number"
                  value={editForm.height}
                  onChange={(e) => setEditForm({...editForm, height: parseInt(e.target.value) || 0})}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Fitness Goal</label>
                <select
                  value={editForm.fitnessGoal}
                  onChange={(e) => setEditForm({...editForm, fitnessGoal: e.target.value})}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="lose_weight">Lose Weight</option>
                  <option value="gain_muscle">Gain Muscle</option>
                  <option value="maintain">Maintain Fitness</option>
                  <option value="endurance">Build Endurance</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Weekly Workout Goal</label>
                <input
                  type="number"
                  min="1"
                  max="7"
                  value={editForm.weeklyGoal}
                  onChange={(e) => setEditForm({...editForm, weeklyGoal: parseInt(e.target.value) || 1})}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>

            <div className="flex space-x-3 mt-6">
              <button
                onClick={handleCancel}
                className="flex-1 bg-gray-100 text-gray-700 py-3 px-4 rounded-lg font-medium hover:bg-gray-200 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleSave}
                className="flex-1 bg-blue-600 text-white py-3 px-4 rounded-lg font-medium hover:bg-blue-700 transition-colors flex items-center justify-center space-x-2"
              >
                <Save className="w-4 h-4" />
                <span>Save</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
          <div className="flex items-center justify-center w-10 h-10 bg-blue-100 rounded-lg mb-3">
            <Calendar className="w-5 h-5 text-blue-600" />
          </div>
          <p className="text-2xl font-bold text-gray-900">{daysActive}</p>
          <p className="text-sm text-gray-500">Days Active</p>
        </div>

        <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
          <div className="flex items-center justify-center w-10 h-10 bg-emerald-100 rounded-lg mb-3">
            <Target className="w-5 h-5 text-emerald-600" />
          </div>
          <p className="text-2xl font-bold text-gray-900">{totalWorkouts}</p>
          <p className="text-sm text-gray-500">Total Workouts</p>
        </div>

        <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
          <div className="flex items-center justify-center w-10 h-10 bg-purple-100 rounded-lg mb-3">
            <Trophy className="w-5 h-5 text-purple-600" />
          </div>
          <p className="text-2xl font-bold text-gray-900">{earnedAchievements.length}</p>
          <p className="text-sm text-gray-500">Achievements</p>
        </div>

        <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
          <div className="flex items-center justify-center w-10 h-10 bg-orange-100 rounded-lg mb-3">
            <Settings className="w-5 h-5 text-orange-600" />
          </div>
          <p className="text-2xl font-bold text-gray-900">{Math.round(totalDuration / 60)}</p>
          <p className="text-sm text-gray-500">Hours Trained</p>
        </div>
      </div>

      {/* Weekly Goal Progress */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-gray-900 flex items-center">
            <Target className="w-5 h-5 mr-2 text-blue-600" />
            Weekly Goal Progress
          </h3>
          <span className="text-sm text-gray-500">
            {thisWeekWorkouts} / {profile.weeklyGoal} workouts
          </span>
        </div>
        
        <div className="space-y-3">
          <div className="flex justify-between text-sm">
            <span className="text-gray-600">Progress</span>
            <span className="font-medium text-gray-900">{Math.min(Math.round(weeklyProgress), 100)}%</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-3">
            <div 
              className="bg-gradient-to-r from-blue-500 to-blue-600 h-3 rounded-full transition-all duration-700 ease-out"
              style={{ width: `${Math.min(weeklyProgress, 100)}%` }}
            ></div>
          </div>
          {weeklyProgress >= 100 && (
            <p className="text-sm text-green-600 font-medium">🎉 Weekly goal achieved!</p>
          )}
        </div>
      </div>

      {/* Achievements */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
          <Trophy className="w-5 h-5 mr-2 text-yellow-600" />
          Achievements ({earnedAchievements.length}/{achievements.length})
        </h3>
        
        <div className="grid md:grid-cols-2 gap-4">
          {achievements.map((achievement, index) => (
            <div key={index} className={`p-4 rounded-lg border transition-all duration-200 ${
              achievement.earned 
                ? 'bg-gradient-to-br from-yellow-50 to-orange-50 border-yellow-200 shadow-sm' 
                : 'bg-gray-50 border-gray-200'
            }`}>
              <div className="flex items-center space-x-3">
                <div className={`text-2xl ${achievement.earned ? '' : 'grayscale opacity-50'}`}>
                  {achievement.icon}
                </div>
                <div className="flex-1">
                  <h4 className={`font-medium ${achievement.earned ? 'text-gray-900' : 'text-gray-500'}`}>
                    {achievement.title}
                  </h4>
                  <p className={`text-sm ${achievement.earned ? 'text-gray-600' : 'text-gray-400'}`}>
                    {achievement.description}
                  </p>
                </div>
                {achievement.earned && (
                  <div className="text-yellow-600 font-medium text-sm">
                    ✓
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Personal Info */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
          <User className="w-5 h-5 mr-2 text-gray-600" />
          Personal Information
        </h3>
        
        <div className="grid md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium text-gray-500">Age</label>
              <p className="text-lg text-gray-900">{profile.age} years old</p>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-500">Weight</label>
              <p className="text-lg text-gray-900">{profile.weight} lbs</p>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-500">Height</label>
              <p className="text-lg text-gray-900">
                {Math.floor(profile.height / 12)}' {profile.height % 12}"
              </p>
            </div>
          </div>
          
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium text-gray-500">Fitness Goal</label>
              <p className="text-lg text-gray-900 capitalize">
                {profile.fitnessGoal.replace('_', ' ')}
              </p>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-500">Weekly Target</label>
              <p className="text-lg text-gray-900">{profile.weeklyGoal} workouts per week</p>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-500">BMI</label>
              <p className="text-lg text-gray-900">
                {((profile.weight / (profile.height * profile.height)) * 703).toFixed(1)}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;