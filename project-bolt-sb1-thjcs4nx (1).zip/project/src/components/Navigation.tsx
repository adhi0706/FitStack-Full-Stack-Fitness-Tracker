import React from 'react';
import { Activity, BarChart3, Dumbbell, User, Home } from 'lucide-react';

interface NavigationProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

const Navigation: React.FC<NavigationProps> = ({ activeTab, onTabChange }) => {
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Home },
    { id: 'workout', label: 'Workout', icon: Dumbbell },
    { id: 'exercises', label: 'Exercises', icon: Activity },
    { id: 'progress', label: 'Progress', icon: BarChart3 },
    { id: 'profile', label: 'Profile', icon: User },
  ];

  return (
    <nav className="bg-white shadow-lg border-t md:border-t-0 md:border-r border-gray-200 fixed bottom-0 left-0 right-0 md:relative md:w-64 md:h-screen z-50">
      <div className="md:p-6">
        <div className="hidden md:block mb-8">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-blue-700 rounded-xl flex items-center justify-center">
              <Dumbbell className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900">FitStack</h1>
              <p className="text-sm text-gray-500">Fitness Tracker</p>
            </div>
          </div>
        </div>

        <ul className="flex md:flex-col justify-around md:justify-start md:space-y-2 py-2 md:py-0">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            
            return (
              <li key={item.id} className="md:w-full">
                <button
                  onClick={() => onTabChange(item.id)}
                  className={`
                    flex flex-col md:flex-row items-center justify-center md:justify-start 
                    space-y-1 md:space-y-0 md:space-x-3 px-3 py-2 md:px-4 md:py-3 
                    rounded-xl transition-all duration-200 w-full group
                    ${isActive 
                      ? 'bg-gradient-to-r from-blue-600 to-blue-700 text-white shadow-lg shadow-blue-600/25' 
                      : 'text-gray-600 hover:bg-gray-50 hover:text-blue-600'
                    }
                  `}
                >
                  <Icon className={`w-5 h-5 md:w-5 md:h-5 transition-transform group-hover:scale-110 ${isActive ? 'text-white' : ''}`} />
                  <span className={`text-xs md:text-sm font-medium ${isActive ? 'text-white' : ''}`}>
                    {item.label}
                  </span>
                </button>
              </li>
            );
          })}
        </ul>
      </div>
    </nav>
  );
};

export default Navigation;