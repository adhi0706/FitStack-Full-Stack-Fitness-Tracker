import React from 'react';
import { TrendingUp, Calendar, Clock, Target, Flame, Award } from 'lucide-react';

interface DashboardProps {
  workouts: any[];
}

const Dashboard: React.FC<DashboardProps> = ({ workouts }) => {
  const thisWeekWorkouts = workouts.filter(w => {
    const workoutDate = new Date(w.date);
    const now = new Date();
    const weekStart = new Date(now.setDate(now.getDate() - now.getDay()));
    return workoutDate >= weekStart;
  }).length;

  const totalWorkouts = workouts.length;
  const thisWeekWeight = workouts
    .filter(w => {
      const workoutDate = new Date(w.date);
      const now = new Date();
      const weekStart = new Date(now.setDate(now.getDate() - now.getDay()));
      return workoutDate >= weekStart;
    })
    .reduce((sum, w) => sum + (w.totalWeight || 0), 0);

  const averageDuration = workouts.length > 0 
    ? workouts.reduce((sum, w) => sum + (w.duration || 0), 0) / workouts.length 
    : 0;

  const stats = [
    {
      title: 'This Week',
      value: thisWeekWorkouts,
      unit: 'workouts',
      icon: Calendar,
      color: 'from-blue-600 to-blue-700',
      bgColor: 'bg-blue-50',
      iconColor: 'text-blue-600'
    },
    {
      title: 'Total Volume',
      value: Math.round(thisWeekWeight),
      unit: 'lbs',
      icon: TrendingUp,
      color: 'from-emerald-600 to-emerald-700',
      bgColor: 'bg-emerald-50',
      iconColor: 'text-emerald-600'
    },
    {
      title: 'Avg Duration',
      value: Math.round(averageDuration),
      unit: 'min',
      icon: Clock,
      color: 'from-purple-600 to-purple-700',
      bgColor: 'bg-purple-50',
      iconColor: 'text-purple-600'
    },
    {
      title: 'Total Sessions',
      value: totalWorkouts,
      unit: 'workouts',
      icon: Target,
      color: 'from-orange-600 to-orange-700',
      bgColor: 'bg-orange-50',
      iconColor: 'text-orange-600'
    }
  ];

  const recentWorkouts = workouts
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .slice(0, 5);

  const achievements = [
    { title: 'First Workout', description: 'Completed your first workout session', earned: totalWorkouts > 0 },
    { title: 'Consistency King', description: 'Completed 3 workouts this week', earned: thisWeekWorkouts >= 3 },
    { title: 'Heavy Lifter', description: 'Lifted over 1000 lbs this week', earned: thisWeekWeight > 1000 },
    { title: 'Dedication', description: 'Completed 10 total workouts', earned: totalWorkouts >= 10 },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 via-purple-600 to-emerald-600 rounded-2xl p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold mb-2">Welcome back!</h1>
            <p className="text-blue-100 text-sm md:text-base">
              Ready to crush your fitness goals today?
            </p>
          </div>
          <div className="hidden md:block">
            <Flame className="w-16 h-16 text-yellow-300 opacity-80" />
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="bg-white rounded-xl p-4 md:p-6 shadow-sm border border-gray-100 hover:shadow-md transition-shadow duration-200">
              <div className="flex items-center justify-between mb-3">
                <div className={`w-10 h-10 rounded-lg ${stat.bgColor} flex items-center justify-center`}>
                  <Icon className={`w-5 h-5 ${stat.iconColor}`} />
                </div>
              </div>
              <div className="space-y-1">
                <p className="text-2xl md:text-3xl font-bold text-gray-900">
                  {stat.value}
                </p>
                <p className="text-xs md:text-sm text-gray-500">
                  {stat.unit}
                </p>
                <p className="text-xs md:text-sm font-medium text-gray-700">
                  {stat.title}
                </p>
              </div>
            </div>
          );
        })}
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {/* Recent Workouts */}
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
            <Calendar className="w-5 h-5 mr-2 text-blue-600" />
            Recent Workouts
          </h3>
          {recentWorkouts.length > 0 ? (
            <div className="space-y-3">
              {recentWorkouts.map((workout, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                  <div>
                    <p className="font-medium text-gray-900">{workout.name}</p>
                    <p className="text-sm text-gray-500">
                      {new Date(workout.date).toLocaleDateString()} • {workout.duration}min
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium text-blue-600">{workout.exercises?.length || 0} exercises</p>
                    <p className="text-xs text-gray-500">{workout.totalWeight || 0} lbs</p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <Clock className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-500">No workouts yet. Start your first session!</p>
            </div>
          )}
        </div>

        {/* Achievements */}
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
            <Award className="w-5 h-5 mr-2 text-yellow-600" />
            Achievements
          </h3>
          <div className="space-y-3">
            {achievements.map((achievement, index) => (
              <div key={index} className={`flex items-center p-3 rounded-lg transition-all duration-200 ${
                achievement.earned 
                  ? 'bg-gradient-to-r from-yellow-50 to-orange-50 border border-yellow-200' 
                  : 'bg-gray-50 border border-gray-200'
              }`}>
                <div className={`w-10 h-10 rounded-full flex items-center justify-center mr-3 ${
                  achievement.earned ? 'bg-yellow-400 text-white' : 'bg-gray-300 text-gray-500'
                }`}>
                  <Award className="w-5 h-5" />
                </div>
                <div className="flex-1">
                  <p className={`font-medium ${achievement.earned ? 'text-gray-900' : 'text-gray-500'}`}>
                    {achievement.title}
                  </p>
                  <p className={`text-sm ${achievement.earned ? 'text-gray-600' : 'text-gray-400'}`}>
                    {achievement.description}
                  </p>
                </div>
                {achievement.earned && (
                  <div className="text-yellow-600 font-medium text-sm">
                    Earned!
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;