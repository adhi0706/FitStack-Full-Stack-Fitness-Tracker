import { Exercise } from '../types';

export const exerciseDatabase: Exercise[] = [
  // Chest
  {
    id: 'chest-1',
    name: 'Bench Press',
    category: 'chest',
    muscleGroups: ['Chest', 'Triceps', 'Shoulders'],
    equipment: ['Barbell', 'Bench'],
    instructions: [
      'Lie flat on bench with feet firmly on floor',
      'Grip barbell slightly wider than shoulder-width',
      'Lower bar to chest in controlled motion',
      'Press bar up until arms are fully extended'
    ],
    difficulty: 'intermediate'
  },
  {
    id: 'chest-2',
    name: 'Push-ups',
    category: 'chest',
    muscleGroups: ['Chest', 'Triceps', 'Core'],
    equipment: ['Bodyweight'],
    instructions: [
      'Start in plank position with hands shoulder-width apart',
      'Lower body until chest nearly touches ground',
      'Push back up to starting position',
      'Keep core engaged throughout movement'
    ],
    difficulty: 'beginner'
  },
  {
    id: 'chest-3',
    name: 'Dumbbell Flyes',
    category: 'chest',
    muscleGroups: ['Chest', 'Shoulders'],
    equipment: ['Dumbbells', 'Bench'],
    instructions: [
      'Lie on bench holding dumbbells above chest',
      'Lower weights in wide arc until chest stretch is felt',
      'Bring dumbbells back together above chest',
      'Maintain slight bend in elbows throughout'
    ],
    difficulty: 'intermediate'
  },

  // Back
  {
    id: 'back-1',
    name: 'Pull-ups',
    category: 'back',
    muscleGroups: ['Lats', 'Rhomboids', 'Biceps'],
    equipment: ['Pull-up Bar'],
    instructions: [
      'Hang from bar with palms facing away',
      'Pull body up until chin clears bar',
      'Lower body with control',
      'Keep core engaged throughout'
    ],
    difficulty: 'intermediate'
  },
  {
    id: 'back-2',
    name: 'Deadlift',
    category: 'back',
    muscleGroups: ['Erector Spinae', 'Glutes', 'Hamstrings'],
    equipment: ['Barbell'],
    instructions: [
      'Stand with feet hip-width apart, bar over mid-foot',
      'Hinge at hips and knees to grip bar',
      'Drive through heels to lift bar',
      'Stand tall with shoulders back'
    ],
    difficulty: 'advanced'
  },

  // Legs
  {
    id: 'legs-1',
    name: 'Squats',
    category: 'legs',
    muscleGroups: ['Quadriceps', 'Glutes', 'Hamstrings'],
    equipment: ['Bodyweight', 'Barbell'],
    instructions: [
      'Stand with feet shoulder-width apart',
      'Lower body by bending knees and hips',
      'Keep chest up and knees tracking over toes',
      'Return to standing position'
    ],
    difficulty: 'beginner'
  },
  {
    id: 'legs-2',
    name: 'Lunges',
    category: 'legs',
    muscleGroups: ['Quadriceps', 'Glutes', 'Hamstrings'],
    equipment: ['Bodyweight', 'Dumbbells'],
    instructions: [
      'Step forward into lunge position',
      'Lower back knee toward ground',
      'Push off front foot to return to start',
      'Alternate legs or complete set on one side'
    ],
    difficulty: 'beginner'
  },

  // Arms
  {
    id: 'arms-1',
    name: 'Bicep Curls',
    category: 'arms',
    muscleGroups: ['Biceps'],
    equipment: ['Dumbbells', 'Barbell'],
    instructions: [
      'Hold weights with arms at sides',
      'Curl weights toward shoulders',
      'Squeeze biceps at top',
      'Lower with control'
    ],
    difficulty: 'beginner'
  },
  {
    id: 'arms-2',
    name: 'Tricep Dips',
    category: 'arms',
    muscleGroups: ['Triceps', 'Chest'],
    equipment: ['Bench', 'Chair'],
    instructions: [
      'Sit on edge of bench with hands beside hips',
      'Slide forward and lower body',
      'Press back up to starting position',
      'Keep elbows close to body'
    ],
    difficulty: 'intermediate'
  },

  // Core
  {
    id: 'core-1',
    name: 'Plank',
    category: 'core',
    muscleGroups: ['Core', 'Shoulders'],
    equipment: ['Bodyweight'],
    instructions: [
      'Start in push-up position',
      'Hold body in straight line',
      'Engage core and breathe normally',
      'Hold for specified duration'
    ],
    difficulty: 'beginner'
  },
  {
    id: 'core-2',
    name: 'Russian Twists',
    category: 'core',
    muscleGroups: ['Obliques', 'Core'],
    equipment: ['Bodyweight', 'Medicine Ball'],
    instructions: [
      'Sit with knees bent, lean back slightly',
      'Lift feet off ground',
      'Rotate torso left and right',
      'Keep core engaged throughout'
    ],
    difficulty: 'intermediate'
  },

  // Cardio
  {
    id: 'cardio-1',
    name: 'Burpees',
    category: 'cardio',
    muscleGroups: ['Full Body'],
    equipment: ['Bodyweight'],
    instructions: [
      'Start standing, drop into squat',
      'Place hands on floor, jump feet back',
      'Perform push-up, jump feet forward',
      'Jump up with arms overhead'
    ],
    difficulty: 'intermediate'
  },
  {
    id: 'cardio-2',
    name: 'Mountain Climbers',
    category: 'cardio',
    muscleGroups: ['Core', 'Shoulders', 'Legs'],
    equipment: ['Bodyweight'],
    instructions: [
      'Start in plank position',
      'Alternate bringing knees to chest',
      'Keep hips level and core tight',
      'Maintain quick, controlled pace'
    ],
    difficulty: 'beginner'
  }
];