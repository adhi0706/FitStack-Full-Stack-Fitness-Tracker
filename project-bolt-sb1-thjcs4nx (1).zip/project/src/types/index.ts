export interface User {
  id: string;
  name: string;
  email: string;
  age: number;
  weight: number;
  height: number;
  fitnessGoal: 'lose_weight' | 'gain_muscle' | 'maintain' | 'endurance';
  weeklyGoal: number;
  createdAt: Date;
}

export interface Exercise {
  id: string;
  name: string;
  category: 'chest' | 'back' | 'shoulders' | 'arms' | 'legs' | 'core' | 'cardio';
  muscleGroups: string[];
  equipment: string[];
  instructions: string[];
  difficulty: 'beginner' | 'intermediate' | 'advanced';
}

export interface WorkoutSet {
  id: string;
  reps: number;
  weight: number;
  duration?: number;
  restTime?: number;
  completed: boolean;
}

export interface WorkoutExercise {
  id: string;
  exerciseId: string;
  exercise: Exercise;
  sets: WorkoutSet[];
  notes?: string;
}

export interface Workout {
  id: string;
  userId: string;
  name: string;
  date: Date;
  duration: number;
  exercises: WorkoutExercise[];
  totalWeight: number;
  totalSets: number;
  completed: boolean;
  notes?: string;
}

export interface WeeklyStats {
  week: string;
  workouts: number;
  totalWeight: number;
  totalDuration: number;
}