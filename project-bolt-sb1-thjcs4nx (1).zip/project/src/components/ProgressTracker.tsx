import React, { useMemo } from 'react';
import { TrendingUp, Calendar, BarChart3, Target, Clock, Weight } from 'lucide-react';

interface ProgressTrackerProps {
  workouts: any[];
}

const ProgressTracker: React.FC<ProgressTrackerProps> = ({ workouts }) => {
  const progressData = useMemo(() => {
    const last8Weeks = [];
    const today = new Date();
    
    for (let i = 7; i >= 0; i--) {
      const weekStart = new Date(today);
      weekStart.setDate(today.getDate() - (today.getDay() + 7 * i));
      weekStart.setHours(0, 0, 0, 0);
      
      const weekEnd = new Date(weekStart);
      weekEnd.setDate(weekStart.getDate() + 6);
      weekEnd.setHours(23, 59, 59, 999);
      
      const weekWorkouts = workouts.filter(w => {
        const workoutDate = new Date(w.date);
        return workoutDate >= weekStart && workoutDate <= weekEnd;
      });
      
      const weekLabel = `${weekStart.getMonth() + 1}/${weekStart.getDate()}`;
      
      last8Weeks.push({
        week: weekLabel,
        workouts: weekWorkouts.length,
        totalWeight: weekWorkouts.reduce((sum, w) => sum + (w.totalWeight || 0), 0),
        totalDuration: weekWorkouts.reduce((sum, w) => sum + (w.duration || 0), 0),
        avgDuration: weekWorkouts.length > 0 ? Math.round(weekWorkouts.reduce((sum, w) => sum + (w.duration || 0), 0) / weekWorkouts.length) : 0
      });
    }
    
    return last8Weeks;
  }, [workouts]);

  const totalStats = useMemo(() => {
    const totalWorkouts = workouts.length;
    const totalWeight = workouts.reduce((sum, w) => sum + (w.totalWeight || 0), 0);
    const totalDuration = workouts.reduce((sum, w) => sum + (w.duration || 0), 0);
    const avgDuration = totalWorkouts > 0 ? Math.round(totalDuration / totalWorkouts) : 0;
    
    const thisWeek = progressData[progressData.length - 1];
    const lastWeek = progressData[progressData.length - 2];
    
    const workoutChange = lastWeek ? ((thisWeek.workouts - lastWeek.workouts) / Math.max(lastWeek.workouts, 1)) * 100 : 0;
    const weightChange = lastWeek ? ((thisWeek.totalWeight - lastWeek.totalWeight) / Math.max(lastWeek.totalWeight, 1)) * 100 : 0;
    
    return {
      totalWorkouts,
      totalWeight,
      totalDuration,
      avgDuration,
      workoutChange,
      weightChange
    };
  }, [workouts, progressData]);

  const maxWorkouts = Math.max(...progressData.map(d => d.workouts), 1);
  const maxWeight = Math.max(...progressData.map(d => d.totalWeight), 1);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600 rounded-xl p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold mb-2">Progress Tracker</h1>
            <p className="text-purple-100">Track your fitness journey and achievements</p>
          </div>
          <div className="hidden md:block">
            <TrendingUp className="w-16 h-16 text-pink-200 opacity-80" />
          </div>
        </div>
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl p-4 md:p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-3">
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
              <Calendar className="w-5 h-5 text-blue-600" />
            </div>
            {totalStats.workoutChange !== 0 && (
              <span className={`text-xs px-2 py-1 rounded-full ${
                totalStats.workoutChange > 0 ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
              }`}>
                {totalStats.workoutChange > 0 ? '+' : ''}{Math.round(totalStats.workoutChange)}%
              </span>
            )}
          </div>
          <p className="text-2xl md:text-3xl font-bold text-gray-900">{totalStats.totalWorkouts}</p>
          <p className="text-sm text-gray-500">Total Workouts</p>
        </div>

        <div className="bg-white rounded-xl p-4 md:p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-3">
            <div className="w-10 h-10 bg-emerald-100 rounded-lg flex items-center justify-center">
              <Weight className="w-5 h-5 text-emerald-600" />
            </div>
            {totalStats.weightChange !== 0 && (
              <span className={`text-xs px-2 py-1 rounded-full ${
                totalStats.weightChange > 0 ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
              }`}>
                {totalStats.weightChange > 0 ? '+' : ''}{Math.round(totalStats.weightChange)}%
              </span>
            )}
          </div>
          <p className="text-2xl md:text-3xl font-bold text-gray-900">
            {Math.round(totalStats.totalWeight).toLocaleString()}
          </p>
          <p className="text-sm text-gray-500">Total Weight (lbs)</p>
        </div>

        <div className="bg-white rounded-xl p-4 md:p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-3">
            <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
              <Clock className="w-5 h-5 text-purple-600" />
            </div>
          </div>
          <p className="text-2xl md:text-3xl font-bold text-gray-900">{totalStats.avgDuration}</p>
          <p className="text-sm text-gray-500">Avg Duration (min)</p>
        </div>

        <div className="bg-white rounded-xl p-4 md:p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-3">
            <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
              <Target className="w-5 h-5 text-orange-600" />
            </div>
          </div>
          <p className="text-2xl md:text-3xl font-bold text-gray-900">
            {Math.round(totalStats.totalDuration / 60)}
          </p>
          <p className="text-sm text-gray-500">Total Hours</p>
        </div>
      </div>

      {/* Charts */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Workout Frequency Chart */}
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
            <BarChart3 className="w-5 h-5 mr-2 text-blue-600" />
            Weekly Workout Frequency
          </h3>
          <div className="space-y-3">
            {progressData.map((week, index) => (
              <div key={index} className="flex items-center space-x-3">
                <span className="text-sm font-medium text-gray-600 w-12">{week.week}</span>
                <div className="flex-1 bg-gray-200 rounded-full h-3 relative overflow-hidden">
                  <div 
                    className="bg-gradient-to-r from-blue-500 to-blue-600 h-full rounded-full transition-all duration-700 ease-out"
                    style={{ width: `${(week.workouts / maxWorkouts) * 100}%` }}
                  ></div>
                </div>
                <span className="text-sm font-medium text-gray-900 w-8">{week.workouts}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Weight Volume Chart */}
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
            <Weight className="w-5 h-5 mr-2 text-emerald-600" />
            Weekly Weight Volume
          </h3>
          <div className="space-y-3">
            {progressData.map((week, index) => (
              <div key={index} className="flex items-center space-x-3">
                <span className="text-sm font-medium text-gray-600 w-12">{week.week}</span>
                <div className="flex-1 bg-gray-200 rounded-full h-3 relative overflow-hidden">
                  <div 
                    className="bg-gradient-to-r from-emerald-500 to-emerald-600 h-full rounded-full transition-all duration-700 ease-out"
                    style={{ width: `${(week.totalWeight / maxWeight) * 100}%` }}
                  ></div>
                </div>
                <span className="text-sm font-medium text-gray-900 w-16 text-right">
                  {week.totalWeight.toLocaleString()}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Recent Progress Summary */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
          <TrendingUp className="w-5 h-5 mr-2 text-purple-600" />
          Progress Summary
        </h3>
        <div className="grid md:grid-cols-3 gap-4">
          <div className="p-4 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-lg border border-blue-100">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-blue-700">This Week</span>
              <Calendar className="w-4 h-4 text-blue-600" />
            </div>
            <p className="text-2xl font-bold text-blue-900">
              {progressData[progressData.length - 1]?.workouts || 0}
            </p>
            <p className="text-xs text-blue-600">workouts completed</p>
          </div>

          <div className="p-4 bg-gradient-to-br from-emerald-50 to-green-50 rounded-lg border border-emerald-100">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-emerald-700">Volume</span>
              <Weight className="w-4 h-4 text-emerald-600" />
            </div>
            <p className="text-2xl font-bold text-emerald-900">
              {Math.round(progressData[progressData.length - 1]?.totalWeight || 0).toLocaleString()}
            </p>
            <p className="text-xs text-emerald-600">pounds lifted</p>
          </div>

          <div className="p-4 bg-gradient-to-br from-purple-50 to-pink-50 rounded-lg border border-purple-100">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-purple-700">Duration</span>
              <Clock className="w-4 h-4 text-purple-600" />
            </div>
            <p className="text-2xl font-bold text-purple-900">
              {progressData[progressData.length - 1]?.totalDuration || 0}
            </p>
            <p className="text-xs text-purple-600">minutes trained</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProgressTracker;